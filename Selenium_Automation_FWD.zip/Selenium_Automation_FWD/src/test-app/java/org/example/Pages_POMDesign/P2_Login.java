package org.example.Pages_POMDesign;

import org.example.Steps_Definitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P2_Login {
    public WebElement navigateLogin_Button(){
        WebElement Login_Button_Ele= Hooks.chromeDriver.findElement(By.cssSelector("a[class=\"ico-login\"]"));
        return Login_Button_Ele;
    }
    public WebElement enterLogin_User(){
        WebElement Login_User_Ele = Hooks.chromeDriver.findElement(By.id("Email"));
        return Login_User_Ele;
    }
    public WebElement enterLogin_Password(){
        WebElement Login_Password_Ele = Hooks.chromeDriver.findElement(By.id("Password"));
        return Login_Password_Ele;
    }
    public WebElement clickLogin_Button(){
        WebElement LoginButEle2 = Hooks.chromeDriver.findElement(By.cssSelector("button[class=\"button-1 login-button\"]"));
        return LoginButEle2;
    }

    public WebElement myAccount_icon(){
        WebElement myAccountButton= Hooks.chromeDriver.findElement(By.cssSelector("a[class=\"ico-account\"]"));
   return myAccountButton;
    }
    public WebElement LogoutFeature(){
        WebElement Logout_button= Hooks.chromeDriver.findElement(By.cssSelector("a[class=\"ico-logout\"]"));
        return Logout_button;
    }}
