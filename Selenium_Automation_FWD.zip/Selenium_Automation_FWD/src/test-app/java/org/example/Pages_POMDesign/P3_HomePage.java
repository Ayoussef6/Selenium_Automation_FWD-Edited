package org.example.Pages_POMDesign;
import org.example.Steps_Definitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class P3_HomePage {



    public WebElement EuroCurrency() {

        WebElement EuroCurrencyElement = Hooks.chromeDriver.findElement(By.id("customerCurrency"));
        return EuroCurrencyElement;
    }

    public List<WebElement> findItem_Prices() {

        List<WebElement> priceListEle = Hooks.chromeDriver.findElements(By.cssSelector("span[class=\"price actual-price\"]"));
        return priceListEle;
    }

    public WebElement searchFeature() {
        WebElement searchFeature_Ele = Hooks.chromeDriver.findElement(By.id("small-searchterms"));
        return searchFeature_Ele;
    }

    public WebElement clickSearch_Btn() {
        WebElement search_Btn_Ele = Hooks.chromeDriver.findElement(By.cssSelector("button[class=\"button-1 search-box-button\"]"));
        return search_Btn_Ele;
    }

    public List<WebElement> findProductList() {
        List<WebElement> productList = Hooks.chromeDriver.findElements(By.cssSelector("h2[class=\"product-title\"]"));
        return productList;
    }

    public WebElement openPDP() {
        WebElement PDP_Element = Hooks.chromeDriver.findElement(By.cssSelector("h2[class=\"product-title\"]>a"));
        return PDP_Element;
    }

    public WebElement verifySKU() {
        WebElement SKU_Elements = Hooks.chromeDriver.findElement(By.cssSelector("div[class=\"sku\"]"));
        return SKU_Elements;
    }
    public List<WebElement> category(){
        List<WebElement> category_Elements= Hooks.chromeDriver.findElements(By.cssSelector("ul[class=\"top-menu notmobile\"]>li>a[href]"));
        return category_Elements;
    }
    public List<WebElement> subCategory(int random){
        List<WebElement> subcategoryEle= Hooks.chromeDriver.findElements(By.xpath("//ul[@class=\"top-menu notmobile\"]/li["+(random+1)+"]/ul[@class=\"sublist first-level\"]/li/a"));
   return subcategoryEle;
    }
    public WebElement sub_Category_Text(){
        WebElement Text= Hooks.chromeDriver.findElement(By.cssSelector("div[class=\"page-title\"]>h1"));
    return Text;
    }
    public List<WebElement> Slider(){
        List<WebElement> Slider_Element= Hooks.chromeDriver.findElements(By.cssSelector("div[id=\"nivo-slider\"]>a"));
        return Slider_Element;
    }
public WebElement facebook_Icon(){
        WebElement facebook_Element= Hooks.chromeDriver.findElement(By.cssSelector("[class=\"facebook\"]>a"));
        return facebook_Element;
}
    public WebElement twitter_Icon(){
        WebElement twitter_Element= Hooks.chromeDriver.findElement(By.className("twitter"));
        return twitter_Element;
    }
    public WebElement rss_Icon(){
        WebElement rss_Element= Hooks.chromeDriver.findElement(By.className("rss"));
        return rss_Element;
    }
    public WebElement youtube_icon(){
        WebElement youtube_Element= Hooks.chromeDriver.findElement(By.className("youtube"));
        return youtube_Element;
    }
    public List<WebElement> clickWishList_Icon(){
    List<WebElement> wishList_Icon_Element= Hooks.chromeDriver.findElements(By.cssSelector("button[title=\"Add to wishlist\"]"));
    return wishList_Icon_Element;
    }
    public WebElement successMessage(){
        WebElement Message_Element= Hooks.chromeDriver.findElement(By.className("content"));
        return Message_Element;
    }
    public WebElement BG_Color(){
        WebElement BG_ColorEle= Hooks.chromeDriver.findElement(By.cssSelector("div [class=\"bar-notification success\"]"));
        return BG_ColorEle;
    }
    public WebElement clickWishList_Button(){
        WebElement wishList_Button_Element= Hooks.chromeDriver.findElement(By.cssSelector("a[class=\"ico-wishlist\"]"));
        return wishList_Button_Element;
    }
    public WebElement verifyWishlistValue(){
        WebElement wishlistValue_Element= Hooks.chromeDriver.findElement(By.cssSelector("input[aria-label=\"Qty.\"]"));
        return wishlistValue_Element;
    }

}
