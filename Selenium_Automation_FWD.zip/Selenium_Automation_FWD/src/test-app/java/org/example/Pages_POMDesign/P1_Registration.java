package org.example.Pages_POMDesign;

import org.example.Steps_Definitions.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P1_Registration {


    public WebElement clickReg(){
       WebElement RegEle = Hooks.chromeDriver.findElement(By.cssSelector("a[href=\"/register?returnUrl=%2F\" ]"));
        return RegEle;
    }
    public WebElement selGender(){
       WebElement genderTypeEle= Hooks.chromeDriver.findElement(By.className("male"));
        return genderTypeEle;
    }
    public WebElement enter_F_Name(){
        WebElement first_Name_Ele= Hooks.chromeDriver.findElement(By.id("FirstName"));
        return first_Name_Ele;
    }
    public WebElement enter_Sec_Name(){
        WebElement sec_Name_Ele= Hooks.chromeDriver.findElement(By.id("LastName"));

        return sec_Name_Ele;
    }
    public WebElement enter_D_Day() {
        WebElement Date_Day = Hooks.chromeDriver.findElement(By.name("DateOfBirthDay"));

        return Date_Day;
    }
        public WebElement enter_D_Month(){
            WebElement Date_Month = Hooks.chromeDriver.findElement(By.name("DateOfBirthMonth"));

            return Date_Month;
    }
    public WebElement enter_D_Year() {

        WebElement Date_Year = Hooks.chromeDriver.findElement(By.name("DateOfBirthYear"));

        return Date_Year;
    }
    public WebElement enterMailAddress(){
        WebElement mail_Ele= Hooks.chromeDriver.findElement(By.id("Email"));
        return mail_Ele;
    }
    public WebElement enterPass_1(){
        WebElement PasswordEle= Hooks.chromeDriver.findElement(By.id("Password"));
        return PasswordEle;
    }
    public WebElement enterPass_2(){
        WebElement Con_PasswordEle= Hooks.chromeDriver.findElement(By.id("ConfirmPassword"));
        return Con_PasswordEle;
    }
    public WebElement reg_ButtonEle(){
        WebElement Reg_ButtonEle= Hooks.chromeDriver.findElement(By.id("register-button"));
        return Reg_ButtonEle;
    }

}
