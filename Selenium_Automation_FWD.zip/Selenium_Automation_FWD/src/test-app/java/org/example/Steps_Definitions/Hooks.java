package org.example.Steps_Definitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.example.Pages_POMDesign.P1_Registration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Hooks {
   public static WebDriver chromeDriver;
static P1_Registration Register;

    @Before
    public static void openChromeBrowser()  {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Ahmed Saad\\Desktop\\Project FWD\\Ahmed Youssef\\Selenium_Automation_FWD\\src\\main\\resources\\chromedriver.exe");
    chromeDriver=new ChromeDriver();
    chromeDriver.manage().window().maximize();
chromeDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    chromeDriver.navigate().to("https://demo.nopcommerce.com/");

    }
    @After
    public static void quitChromeBrowser()throws InterruptedException{
        Thread.sleep(3000);
        chromeDriver.quit();
    }
}
