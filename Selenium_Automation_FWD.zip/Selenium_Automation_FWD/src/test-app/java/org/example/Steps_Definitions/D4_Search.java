package org.example.Steps_Definitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P3_HomePage;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D4_Search {
    P3_HomePage search_Objective=new P3_HomePage();

    @When("user enter {string} into search field")
    public void userEnter(String input) {
        search_Objective.searchFeature().sendKeys(input);
    }
    @And("user click on search button")
    public void clickSearchButt() {
        search_Objective.clickSearch_Btn().click();
    }

    @Then("Relative results of {string} are displayed in PLP")
    public void displayedResult(String results) {
        SoftAssert products_Ass=new SoftAssert();
        String expectedResult=results;
        for (int i = 0; i < search_Objective.findProductList().size(); i++)
        {
            String ActualResult = search_Objective.findProductList().get(i).getText().toLowerCase();
            products_Ass.assertEquals(ActualResult.contains(expectedResult),true,"1st assertion_Product is not found");
        }
        String expectedURL="https://demo.nopcommerce.com/search?q=";
        String actualURL= Hooks.chromeDriver.getCurrentUrl();
        products_Ass.assertTrue(actualURL.contains(expectedURL),"Second Assertion_URL");

        products_Ass.assertAll();

    }

    @Then("Relative results of {string} are displayed in PDP")
  public void itemsDisplayedInPLP(String items) {
        String expectedSKU=items;
        search_Objective.openPDP().click();
           String actualSKU=  search_Objective.verifySKU().getText();
            Assert.assertEquals(actualSKU.contains(expectedSKU),true,"1st Assertion_wrong sku");
   }
    }

