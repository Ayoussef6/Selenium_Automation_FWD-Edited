package org.example.Steps_Definitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P3_HomePage;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import java.util.Random;

public class D5_hoverCategories {
    int CategoryNu=new Random().nextInt(3);
    int SubCategoryNu=new Random().nextInt(3);


    P3_HomePage hoover_Object=new P3_HomePage();
    @When("user hover over category menu and select item from subcategory list")
    public void hooverCategoryPage() throws InterruptedException {

        Actions hoover=new Actions(Hooks.chromeDriver);
        hoover.moveToElement(hoover_Object.category().get(CategoryNu)).perform();
      String categoryName  =hoover_Object.category().get(CategoryNu).getText();
        System.out.println(categoryName);
        hoover_Object.subCategory(CategoryNu).get(SubCategoryNu).click();
        Thread.sleep(3000);
    }


    @Then("user is able to see the subcategory page")
    public void displaySubcategoryPage() {
        SoftAssert category_Ass=new SoftAssert();

        String subCategory_Name=hoover_Object.subCategory(CategoryNu).get(SubCategoryNu).getText().toLowerCase();
        String item_Text=hoover_Object.sub_Category_Text().getText().toLowerCase();
        category_Ass.assertEquals(item_Text.contains(subCategory_Name),true,"first Assertion_different item");

        String actualURL= Hooks.chromeDriver.getCurrentUrl();
      String expectedURL="https://demo.nopcommerce.com/"+item_Text;
        category_Ass.assertEquals(actualURL.contains(expectedURL),true,"sec assertion_URL is different");
        category_Ass.assertAll();
    }
}
