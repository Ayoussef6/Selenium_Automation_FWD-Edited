package org.example.Steps_Definitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P3_HomePage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;

public class D7__followUs {
    P3_HomePage links_Object=new P3_HomePage();
    WebDriverWait wait=new WebDriverWait(Hooks.chromeDriver, Duration.ofSeconds(5));


    @When("user click on facebook icon")
    public void clickFacebook() throws InterruptedException {
        links_Object.facebook_Icon().click();


    }
    @Then("user is directed to {string}")
    public void userIsDirectedTo(String URL) {
        ArrayList<String> tabs=  new ArrayList<>(Hooks.chromeDriver.getWindowHandles());
        Hooks.chromeDriver.switchTo().window(tabs.get(1));
        wait.until(ExpectedConditions.urlToBe(URL));
        String actualURL= Hooks.chromeDriver.getCurrentUrl();
        System.out.println("Saad"+actualURL);
        Assert.assertEquals(actualURL,URL,"The URL is Wrong");
    }

    @When("user click on twitter icon")
    public void clickTwitterIcon() {
        links_Object.twitter_Icon().click();
    }


    @When("user click on rss icon")
    public void clickRssIcon() {
        links_Object.rss_Icon().click();
    }



    @When("user click on youtube icon")
    public void clickYoutubeIcon() {
        links_Object.youtube_icon().click();
    }


}
