package org.example.Steps_Definitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P3_HomePage;
import org.testng.Assert;


public class D6_HomeSliders {
    P3_HomePage slider_Object=new P3_HomePage();
    @When("user click on the first slider")
    public void clickFirstSlider() throws InterruptedException {

        slider_Object.Slider().get(0).click();
            Thread.sleep(3000);

    }
    @Then("user is directed to {string} item page")
    public void userIsDirectedToItemPage(String URL) {
        String actualURL= Hooks.chromeDriver.getCurrentUrl();
        Assert.assertEquals(actualURL.contains(URL),true,"Wrong URL");
    }
    @When("user click on the second slider")
    public void clickSecondSlider()  {
        slider_Object.Slider().get(1).click();

    }



}
