package org.example.Steps_Definitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P1_Registration;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

public class D1_Registration {
    P1_Registration Register_Obj=new P1_Registration();
    @Given("Guest User navigate to the register page")
            public void navigateRegisterPage()
    {
        Register_Obj.clickReg().click();
    }

    @When("Guest user select gender type")
    public void selectGender() {
        Register_Obj.selGender().click();
    }

    @And("Guest user enter firstname {string} and lastname {string}")
    public void enterName(String Name1, String Name2) {
        Register_Obj.enter_F_Name().sendKeys(Name1);
        Register_Obj.enter_Sec_Name().sendKeys(Name2);
    }


    @And("Guest user enter date of birth")
    public void enterBirthDate() {
        Select Day=new Select(Register_Obj.enter_D_Day());
        Day.selectByIndex(10);
        Select Month=new Select(Register_Obj.enter_D_Month());
        Month.selectByValue("6");
        Select Year=new Select(Register_Obj.enter_D_Year());
        Year.selectByValue("1991");


    }
    @And("Guest user enter email address {string}")
    public void enterEmail(String mail) {
        Register_Obj.enterMailAddress().sendKeys(mail);

    }
    @And("Guest user fills Password field {string} and confirmation Password field {string}")
    public void enterPassword(String pass, String confPass) {
        Register_Obj.enterPass_1().sendKeys(pass);
        Register_Obj.enterPass_2().sendKeys(confPass);
    }

    @And("Guest user clicks on register button")
    public void clicksRegisterBut() throws InterruptedException {
        Register_Obj.reg_ButtonEle().click();
        Thread.sleep(500);
    }

    @Then("success message is displayed")
    public void successMessageIsDisplayed() {
        SoftAssert softR =new SoftAssert();
        String ExpectedResult="Your registration completed";
        String ActualResult= Hooks.chromeDriver.findElement(By.cssSelector("div[class=\"result\"]")).getText();
        System.out.println(ActualResult);
                softR.assertEquals(ActualResult.contains(ExpectedResult),true);
               String ExpectedColor="rgba(76, 177, 124, 1)";
               String ActualColor= Hooks.chromeDriver.findElement(By.cssSelector("div[class=\"result\"]")).getCssValue("color");
        softR.assertTrue(ActualColor.equals(ExpectedColor),"sec Assertion_Wrong color message");
        System.out.println(ActualColor);
        softR.assertAll();
    }



}
