package org.example.Steps_Definitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P3_HomePage;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class D8__Wishlist {
    P3_HomePage wishlist=new P3_HomePage();
    @When("user click on wishlist Icon")
    public void clickWishlistIcon() throws InterruptedException {
        wishlist.clickWishList_Icon().get(2).click();
        Thread.sleep(2000);


    }

    @Then("item is added successfully to  wishlist")
    public void itemAddedSuccessfully() {
 String ActualMessage=wishlist.successMessage().getText();
        SoftAssert soft=new SoftAssert();
        String ExpectedMessage="The product has been added to your wishlist";

        soft.assertEquals(ActualMessage.contains(ExpectedMessage),true,"1st Assertion_wrong message");

        String ExpectedBG_Color="#4bb07a";
        String ActualBG_Color=wishlist.BG_Color().getCssValue("background-color");
        String ActualBackgroundColorHex= Color.fromString(ActualBG_Color).asHex();

 soft.assertEquals(ActualBackgroundColorHex.equals(ExpectedBG_Color),true,"sec_Assertion Wrong Back_ground color");
        soft.assertAll();
    }

    @When("user click on wishlist button")
    public void userClickOnWishlistButton() throws InterruptedException {
        WebDriverWait wait=new WebDriverWait(Hooks.chromeDriver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.invisibilityOf(wishlist.BG_Color()));
        wishlist.clickWishList_Button().click();
        Thread.sleep(1000);
    }



    @Then("user is directed to {string} wishlist page")
    public void Direct_ToWishlistPage(String wishlistURL) {
        SoftAssert soft_Wishlist=new SoftAssert();
        String ActualURL= Hooks.chromeDriver.getCurrentUrl();
        System.out.println(ActualURL);
        soft_Wishlist.assertEquals(ActualURL.equals(wishlistURL),true,"1st Assertion_wrong wishlist URL");
        String QTY=wishlist.verifyWishlistValue().getAttribute("value");
        int qtyValue= Integer.valueOf(QTY);
        System.out.println(qtyValue);
        soft_Wishlist.assertTrue(qtyValue>0,"Sec Assertion_number is <= 0");
        soft_Wishlist.assertAll();

    }
}
