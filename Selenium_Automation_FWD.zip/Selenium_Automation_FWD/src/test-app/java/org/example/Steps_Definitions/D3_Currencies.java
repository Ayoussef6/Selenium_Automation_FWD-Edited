package org.example.Steps_Definitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P3_HomePage;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class D3_Currencies {
    P3_HomePage Curr_Objective= new P3_HomePage();
    @When("user select Euro currency from dropdown_list")
    public void selectEuro() {
        Select selectCurrency = new Select(Curr_Objective.EuroCurrency());
        selectCurrency.selectByVisibleText("Euro");


    }


    @Then("All products are displayed with Euro currency")
    public void displayEuro_Currency() {
        String expectedResult="€";
        for(int i=0;i < Curr_Objective.findItem_Prices().size();i++)
        {
            String ActualResult= Curr_Objective.findItem_Prices().get(i).getText();
            Assert.assertEquals(ActualResult.contains(expectedResult),true,"currency  is not match");
        }

    }
}
