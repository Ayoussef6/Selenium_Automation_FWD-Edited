package org.example.Steps_Definitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_POMDesign.P2_Login;
import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D2_Login {
    P2_Login login_Object=new P2_Login();
    @Given("user navigate to login page")
    public void navigateLoginPage(){
        login_Object.navigateLogin_Button().click();
    }

    @When("user enter email {string} and password {string}")
    public void userEnterEmailAndPassword(String email, String pass) {
        login_Object.enterLogin_User().clear();
        login_Object.enterLogin_User().sendKeys(email);
        login_Object.enterLogin_Password().sendKeys(pass);
    }

    @And("user press on login button")
    public void userPressOnLoginButton() {
        login_Object.clickLogin_Button().click();

    }

    @Then("user Could login to the system successfully")
    public void userCouldLoginToTheSystemSuccessfully() {
        login_Object.myAccount_icon().isDisplayed();
        login_Object.LogoutFeature().isDisplayed();
       String ActualResult= Hooks.chromeDriver.getCurrentUrl();
       String ExpectedResult="https://demo.nopcommerce.com/";
        Assert.assertEquals(ActualResult.contains(ExpectedResult),true);
    }


    @Then("user is not allowed to login to the system")
    public void userIsNotAllowedToLoginToTheSystem() {
       SoftAssert  soft_L =new SoftAssert();
        String ActualResult= Hooks.chromeDriver.findElement(By.cssSelector("div[class=\"message-error validation-summary-errors\"]")).getText();
        String ExpectedResult="Login was unsuccessful. Please correct the errors and try again.";
        soft_L.assertEquals(ActualResult.contains(ExpectedResult),true,"1st Assertion");

        String ActualTextColor= Hooks.chromeDriver.findElement(By.cssSelector("div[class=\"message-error validation-summary-errors\"]")).getCssValue("color");
       String HexColor=Color.fromString(ActualTextColor).asHex();
        String ExpectedTextColor="#e4434b";
        System.out.println(HexColor);
        soft_L.assertEquals(HexColor.equals(ExpectedTextColor),true,"sec Assertion");
        soft_L.assertAll();
    }


}
